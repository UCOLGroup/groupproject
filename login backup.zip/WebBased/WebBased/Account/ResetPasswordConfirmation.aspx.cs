﻿using System.Web.UI;

namespace WebBased.Account
{
    public partial class ResetPasswordConfirmation : Page
    {
    }
}