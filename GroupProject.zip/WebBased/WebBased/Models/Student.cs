﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace WebBased.Models
{
    public class Student
    {
        public int student_id { get; set; }

        public string first_name { get; set; }

        public string last_name { get; set; }

        public int phone { get; set; }

        public string address { get; set; }

        public string password { get; set; }

        public string email { get; set; }

        public string user_name { get; set; }



    }
}